#pragma once
class Cuadrado
{
private:   //atributos
	int lado;
	int area; //analisis

public:    //metodos
	Cuadrado(void);//constructor
	//metodos de acceso
	//para accesar o revisar el contenido de los atributos
	int Get_lado();
	int Get_area();
	
	//para darle valor a los atributos
	void Set_lado(int l);
	void Set_area(int a);

	//operaciones especificas
	int Calcular();
};

