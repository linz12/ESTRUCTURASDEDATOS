#pragma once
#include "Cuadrado.h"
#include <iostream> //Manejo de interaccion
#include "msclr\marshal_cppstd.h" //Manejar texto

namespace ejemplocuadrado {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblLado;
	protected: 
	private: System::Windows::Forms::Label^  lblArea;
	private: System::Windows::Forms::TextBox^  txtLado;
	private: System::Windows::Forms::TextBox^  txtArea;
	private: System::Windows::Forms::Button^  btCalcular;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblLado = (gcnew System::Windows::Forms::Label());
			this->lblArea = (gcnew System::Windows::Forms::Label());
			this->txtLado = (gcnew System::Windows::Forms::TextBox());
			this->txtArea = (gcnew System::Windows::Forms::TextBox());
			this->btCalcular = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// lblLado
			// 
			this->lblLado->AutoSize = true;
			this->lblLado->Location = System::Drawing::Point(31, 40);
			this->lblLado->Name = L"lblLado";
			this->lblLado->Size = System::Drawing::Size(45, 20);
			this->lblLado->TabIndex = 0;
			this->lblLado->Text = L"Lado";
			// 
			// lblArea
			// 
			this->lblArea->AutoSize = true;
			this->lblArea->Location = System::Drawing::Point(33, 113);
			this->lblArea->Name = L"lblArea";
			this->lblArea->Size = System::Drawing::Size(43, 20);
			this->lblArea->TabIndex = 1;
			this->lblArea->Text = L"Area";
			// 
			// txtLado
			// 
			this->txtLado->Location = System::Drawing::Point(111, 43);
			this->txtLado->Name = L"txtLado";
			this->txtLado->Size = System::Drawing::Size(105, 26);
			this->txtLado->TabIndex = 2;
			// 
			// txtArea
			// 
			this->txtArea->Location = System::Drawing::Point(111, 112);
			this->txtArea->Name = L"txtArea";
			this->txtArea->Size = System::Drawing::Size(104, 26);
			this->txtArea->TabIndex = 3;
			// 
			// btCalcular
			// 
			this->btCalcular->Location = System::Drawing::Point(91, 189);
			this->btCalcular->Name = L"btCalcular";
			this->btCalcular->Size = System::Drawing::Size(99, 28);
			this->btCalcular->TabIndex = 4;
			this->btCalcular->Text = L"Calcular";
			this->btCalcular->UseVisualStyleBackColor = true;
			this->btCalcular->Click += gcnew System::EventHandler(this, &Form1::btCalcular_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(278, 244);
			this->Controls->Add(this->btCalcular);
			this->Controls->Add(this->txtArea);
			this->Controls->Add(this->txtLado);
			this->Controls->Add(this->lblArea);
			this->Controls->Add(this->lblLado);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
		 Cuadrado cuadradito; //Creando el objeto cuadradito
		 cuadradito.Set_lado(System::Convert::ToInt32(txtLado->Text));
		 int areafin;
		 areafin=cuadradito.Calcular();
		 txtArea->Text=System::Convert::ToString(areafin);
			 }
};
}

