#include "StdAfx.h"
#include "Triangulo.h"


Triangulo::Triangulo(void)
{
}

//para accesar o revisar el contenido de los atributos
	int Triangulo::Get_base()
	{
		return base;
	}
	int Triangulo::Get_altura()
	{
		return altura;
	}

	void Triangulo::Set_base(int b)
	{
		base=b;
	}
	void Triangulo::Set_altura(int h)
	{
		altura=h;
	}

	int Triangulo::Calcular()
	{
		return ((base*altura)/2);
	}