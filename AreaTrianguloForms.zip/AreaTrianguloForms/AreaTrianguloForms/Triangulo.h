#pragma once
class Triangulo
{
private:  //atributos
	int base;
	int altura;

public:				   //metodos
	Triangulo(void);  //constructor

	int Get_base();
	int Get_altura();
	
	void Set_base(int b);
	void Set_altura(int h);

	int Calcular();
};

