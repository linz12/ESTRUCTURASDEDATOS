#pragma once
#include "Triangulo.h"

namespace AreaTrianguloForms {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtBase;
	protected: 
	private: System::Windows::Forms::TextBox^  txtAltura;
	private: System::Windows::Forms::Label^  lblBase;
	private: System::Windows::Forms::Label^  lblAltura;
	private: System::Windows::Forms::Button^  btnCalcular;
	private: System::Windows::Forms::TextBox^  txtArea;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtBase = (gcnew System::Windows::Forms::TextBox());
			this->txtAltura = (gcnew System::Windows::Forms::TextBox());
			this->lblBase = (gcnew System::Windows::Forms::Label());
			this->lblAltura = (gcnew System::Windows::Forms::Label());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->txtArea = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// txtBase
			// 
			this->txtBase->Location = System::Drawing::Point(102, 40);
			this->txtBase->Name = L"txtBase";
			this->txtBase->Size = System::Drawing::Size(100, 22);
			this->txtBase->TabIndex = 0;
			// 
			// txtAltura
			// 
			this->txtAltura->Location = System::Drawing::Point(102, 89);
			this->txtAltura->Name = L"txtAltura";
			this->txtAltura->Size = System::Drawing::Size(100, 22);
			this->txtAltura->TabIndex = 1;
			// 
			// lblBase
			// 
			this->lblBase->AutoSize = true;
			this->lblBase->Location = System::Drawing::Point(13, 40);
			this->lblBase->Name = L"lblBase";
			this->lblBase->Size = System::Drawing::Size(40, 17);
			this->lblBase->TabIndex = 2;
			this->lblBase->Text = L"Base";
			// 
			// lblAltura
			// 
			this->lblAltura->AutoSize = true;
			this->lblAltura->Location = System::Drawing::Point(13, 89);
			this->lblAltura->Name = L"lblAltura";
			this->lblAltura->Size = System::Drawing::Size(45, 17);
			this->lblAltura->TabIndex = 3;
			this->lblAltura->Text = L"Altura";
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(102, 186);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(75, 23);
			this->btnCalcular->TabIndex = 4;
			this->btnCalcular->Text = L"Calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// txtArea
			// 
			this->txtArea->Location = System::Drawing::Point(102, 138);
			this->txtArea->Name = L"txtArea";
			this->txtArea->Size = System::Drawing::Size(100, 22);
			this->txtArea->TabIndex = 5;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 138);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(72, 17);
			this->label1->TabIndex = 6;
			this->label1->Text = L"Resultado";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(77, 9);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(137, 17);
			this->label2->TabIndex = 7;
			this->label2->Text = L"Area de un triangulo";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(282, 253);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txtArea);
			this->Controls->Add(this->btnCalcular);
			this->Controls->Add(this->lblAltura);
			this->Controls->Add(this->lblBase);
			this->Controls->Add(this->txtAltura);
			this->Controls->Add(this->txtBase);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
			 Triangulo triangulito;
			 triangulito.Set_base(System::Convert::ToInt32(txtBase->Text));
			 triangulito.Set_altura(System::Convert::ToInt32(txtAltura->Text));
			 int areafin;
			 areafin=triangulito.Calcular();
			 txtArea->Text=System::Convert::ToString(areafin);
		 }
};
}

