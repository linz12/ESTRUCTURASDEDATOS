// PilaConsola.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Pila.h"
#include <iostream>
#include "conio.h"

using namespace std;

void main()
{
	Pila pilita;
	int elem;
	cout<<"ingrese 10 datos:"<<endl;
	for(int i=0;i<10;i++)
	{
		cin>>elem;
		pilita.Apilar(elem);
	}
	cout<<"------MOSTRANDO PILA------"<<endl;
	pilita.verpila();
	cout<<"------MOSTRANDO TOPES------"<<endl;
	for(int i=0; i<10; i++)
	{
		cout<<"tope:"<<pilita.gettope()<<endl;
		pilita.verpila();
		pilita.Desapilar();
		cout<<"tope elimunado"<<endl;
	}
	getch();
}

