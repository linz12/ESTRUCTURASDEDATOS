#pragma once

#define MAX 10

class Pila
{
private:
	int pila[MAX];
	int tope;

public:
	Pila(void);
	~Pila(void);

	int gettope();
	bool Apilar(int elemento);
	void verpila();
	bool PilaVacia();
	bool pilallena(int tope);
	bool Desapilar();
	int ValorTope();
};

