// ejercicio3vector.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Vector.h"
#include "conio.h"

#define MAX 100

using namespace std;

void main()
{double notas[MAX];
 int tam;
 Vector vector1;
 do {
		cout<<"Ingrese el tamanio del vector : ";
		cin>>tam;
	} while ((tam>MAX) || (tam<=0));
 vector1.cargar(notas,tam);
 cout<<"El promedio de las notas es: "<<vector1.promedio (notas,tam)<<endl;
 getch();
 
	
}

