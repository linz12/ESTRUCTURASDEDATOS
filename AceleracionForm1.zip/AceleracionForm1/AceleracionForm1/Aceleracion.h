#pragma once
class Aceleracion
{
private:    //atributos
	int Tiempo; //analisis
	int VelocidadInicial;
	int VelocidadFinal;
	int Resultado;

public: //metodos
	Aceleracion(void); //constuctor 
	
	//metodos de acceso
	//para accesar o revisar el contenido de los atributos
	int Get_VelocidadInicial();
	int Get_VelocidadFinal();
	int Get_Tiempo();
	int Get_Resultado();
	
	//para darle valor a los atributos
	void Set_VelocidadInicial(int vi);
	void Set_VelocidadFinal(int vf);
	void Set_Tiempo(int t);
	void Set_Resultado(int r);


	//operaciones especificas
	int Calcular();
};