#pragma once
#include "Aceleracion.h"
#include "iostream" //Manejo de interaccion
#include "msclr\marshal_cppstd.h" //Manejar texto

namespace AceleracionForm1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr;


	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btnCalcular;
	private: System::Windows::Forms::TextBox^  txtVelocidadInicial;
	protected: 


	protected: 

	private: System::Windows::Forms::TextBox^  txtTiempo;
	private: System::Windows::Forms::TextBox^  txtVelocidadFinal;

	private: System::Windows::Forms::Label^  lblVelocidadInicial;

	private: System::Windows::Forms::Label^  lblVelocidadFinal;




	private: System::Windows::Forms::Label^  lblTiempo;
	private: System::Windows::Forms::Label^  lblResultado;
	private: System::Windows::Forms::TextBox^  txtResultado;




	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->txtVelocidadInicial = (gcnew System::Windows::Forms::TextBox());
			this->txtTiempo = (gcnew System::Windows::Forms::TextBox());
			this->txtVelocidadFinal = (gcnew System::Windows::Forms::TextBox());
			this->lblVelocidadInicial = (gcnew System::Windows::Forms::Label());
			this->lblVelocidadFinal = (gcnew System::Windows::Forms::Label());
			this->lblTiempo = (gcnew System::Windows::Forms::Label());
			this->lblResultado = (gcnew System::Windows::Forms::Label());
			this->txtResultado = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(112, 174);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(75, 23);
			this->btnCalcular->TabIndex = 0;
			this->btnCalcular->Text = L"Calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// txtVelocidadInicial
			// 
			this->txtVelocidadInicial->Location = System::Drawing::Point(153, 44);
			this->txtVelocidadInicial->Name = L"txtVelocidadInicial";
			this->txtVelocidadInicial->Size = System::Drawing::Size(100, 22);
			this->txtVelocidadInicial->TabIndex = 1;
			// 
			// txtTiempo
			// 
			this->txtTiempo->Location = System::Drawing::Point(153, 129);
			this->txtTiempo->Name = L"txtTiempo";
			this->txtTiempo->Size = System::Drawing::Size(100, 22);
			this->txtTiempo->TabIndex = 3;
			// 
			// txtVelocidadFinal
			// 
			this->txtVelocidadFinal->Location = System::Drawing::Point(153, 86);
			this->txtVelocidadFinal->Name = L"txtVelocidadFinal";
			this->txtVelocidadFinal->Size = System::Drawing::Size(100, 22);
			this->txtVelocidadFinal->TabIndex = 4;
			// 
			// lblVelocidadInicial
			// 
			this->lblVelocidadInicial->AutoSize = true;
			this->lblVelocidadInicial->Location = System::Drawing::Point(35, 45);
			this->lblVelocidadInicial->Name = L"lblVelocidadInicial";
			this->lblVelocidadInicial->Size = System::Drawing::Size(109, 17);
			this->lblVelocidadInicial->TabIndex = 5;
			this->lblVelocidadInicial->Text = L"Velocidad Inicial";
			this->lblVelocidadInicial->Click += gcnew System::EventHandler(this, &Form1::label1_Click);
			// 
			// lblVelocidadFinal
			// 
			this->lblVelocidadFinal->AutoSize = true;
			this->lblVelocidadFinal->Location = System::Drawing::Point(35, 91);
			this->lblVelocidadFinal->Name = L"lblVelocidadFinal";
			this->lblVelocidadFinal->Size = System::Drawing::Size(104, 17);
			this->lblVelocidadFinal->TabIndex = 6;
			this->lblVelocidadFinal->Text = L"Velocidad Final";
			// 
			// lblTiempo
			// 
			this->lblTiempo->Location = System::Drawing::Point(38, 143);
			this->lblTiempo->Name = L"lblTiempo";
			this->lblTiempo->Size = System::Drawing::Size(72, 20);
			this->lblTiempo->TabIndex = 0;
			this->lblTiempo->Text = L"Tiempo";
			this->lblTiempo->Click += gcnew System::EventHandler(this, &Form1::label3_Click);
			// 
			// lblResultado
			// 
			this->lblResultado->AutoSize = true;
			this->lblResultado->Location = System::Drawing::Point(38, 219);
			this->lblResultado->Name = L"lblResultado";
			this->lblResultado->Size = System::Drawing::Size(72, 17);
			this->lblResultado->TabIndex = 7;
			this->lblResultado->Text = L"Resultado";
			this->lblResultado->Click += gcnew System::EventHandler(this, &Form1::label4_Click);
			// 
			// txtResultado
			// 
			this->txtResultado->Location = System::Drawing::Point(156, 219);
			this->txtResultado->Name = L"txtResultado";
			this->txtResultado->Size = System::Drawing::Size(100, 22);
			this->txtResultado->TabIndex = 8;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(282, 253);
			this->Controls->Add(this->txtResultado);
			this->Controls->Add(this->lblResultado);
			this->Controls->Add(this->lblTiempo);
			this->Controls->Add(this->lblVelocidadFinal);
			this->Controls->Add(this->lblVelocidadInicial);
			this->Controls->Add(this->txtVelocidadFinal);
			this->Controls->Add(this->txtTiempo);
			this->Controls->Add(this->txtVelocidadInicial);
			this->Controls->Add(this->btnCalcular);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void label3_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label4_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
			  Aceleracion aceleradita; //Creando el objeto cuadradito
		 aceleradita.Set_Tiempo(System::Convert::ToInt32(txtTiempo->Text));
		 aceleradita.Set_VelocidadInicial(System::Convert::ToInt32(txtVelocidadInicial->Text));
		 aceleradita.Set_VelocidadFinal(System::Convert::ToInt32(txtVelocidadFinal->Text));
		 int Resultadofin;
		 Resultadofin=aceleradita.Calcular();
		 txtResultado->Text=System::Convert::ToString(Resultadofin);
		 }
};
}

