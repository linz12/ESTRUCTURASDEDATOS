#include "StdAfx.h"
#include "Aceleracion.h"//he

Aceleracion::Aceleracion(void)
{
}

//para accesar o revisar el contenido de los atributos
int Aceleracion::Get_VelocidadInicial()
{
	return VelocidadInicial;
}
int Aceleracion::Get_VelocidadFinal()
{
	return VelocidadFinal;
}
int Aceleracion::Get_Tiempo()
{
	return Tiempo;
}
int Aceleracion::Get_Resultado()
{
	return Resultado;
}
	
//para darle valor a los atributos
void Aceleracion::Set_VelocidadInicial(int vi)
{
		VelocidadInicial=vi;
}
void Aceleracion::Set_VelocidadFinal(int vf)
{
		VelocidadFinal=vf;
}
void Aceleracion::Set_Tiempo(int t)
{
		Tiempo=t;
}
void Aceleracion::Set_Resultado(int r)
{
		Resultado=r;
}


//operaciones especificas
int Aceleracion::Calcular()
{
		Resultado=((VelocidadFinal-VelocidadInicial)/Tiempo);
		return Resultado;
}