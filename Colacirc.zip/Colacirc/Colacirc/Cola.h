#pragma once
#include "Nodo.h"

class Cola: public Nodo
{
public:
	bool Encolar(int elem,int pos);
	bool Desencolar(int pos);

};

