// Colacirc.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Cola.h"
#include "conio.h"
using namespace std;

void main()
{int elem;
 int num=0;
 Cola colita;
 colita.set_frente(0);
 colita.Set_numero(0);
 colita.Set_tamano(4);
 int posi,opc;
 do{cout<<"1.Encolar"<<endl;
    cout<<"2.Desencolar"<<endl;
	cout<<"3.Cola Llena?"<<endl;
    cout<<"OPCION: ";cin>>opc;
	switch(opc)
	{case 1:
	 posi=(colita.Get_frente() + colita.Get_numero()) % colita.Get_tamano();
	 cout<<"Ingrese un dato: ";cin>>elem;
	 if (colita.Encolar(elem,posi)){
				 num++;
				 colita.Set_numero(num);
				 cout<<"Elemento encolado exitosamente"<<endl;
	}
	 else{cout<<"VERIFIQUE SI LA COLA NO ESTA LLENA"<<endl;}
	 break;
	case 2:
		if(colita.Get_numero()==0){cout<<"La Cola Esta Vacia"<<endl;}else{
		 posi=(colita.Get_frente()%colita.Get_tamano());
			 if (colita.Desencolar(posi)) {cout<<"Elemento desencolado excitosamente "<<endl;
			 }
			 int fren=colita.Get_frente()+1;
			 colita.set_frente(fren);
			 num--;
			 colita.Set_numero(num);
		}
		break;
	case 3:
		if(colita.Get_numero()==colita.Get_tamano())
		{
			cout<<"COLA LLENA"<<endl;
		}
		else
		{if(colita.Get_numero()==0)
		 {cout<<"COLA VACIA"<<endl;
		 }
		else 
		 {cout<<"La cola no esta llena aun"<<endl;
		 }
		}
	break;
	}
    }while(opc<4);
	getch();
	
 }


