#include "StdAfx.h"
#include "Nodo.h"


Nodo::Nodo(void)
{
}


Nodo::~Nodo(void)
{
}
void Nodo::set_frente(int frent)
{
	frente=frent;
}
void Nodo::Set_numero(int num)
{
	n=num;
}
void Nodo::Set_tamano(int tama)
{
	tam=tama;
}
	int Nodo::Get_frente()
	{
		return frente;
	}
	int Nodo::Get_numero()
	{
		return n;
	}
	int Nodo::Get_tamano()
	{
		return tam;
	}
