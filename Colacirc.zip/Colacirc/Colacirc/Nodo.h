#pragma once
#define MAX 5
class Nodo
{protected:
 int frente,n,dato,tam;
 int v[MAX];
public:
	Nodo(void);
	~Nodo(void);
	void set_frente(int frent); 
	void Set_numero(int num);
	void Set_tamano(int tama);
	int Get_frente();
	int Get_numero();
	int Get_tamano();
};

