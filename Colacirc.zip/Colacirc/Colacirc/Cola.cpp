#include "StdAfx.h"
#include "Cola.h"
#include <iostream>
using namespace std;


bool Cola::Encolar(int elem,int pos)
{if(n==Get_tamano())
	{ return false;
	}
	else
	{
		if(v[pos]==0)
		{v[pos]=elem;
		 return true;
		}
		else 
		{int i=Get_tamano();
		while(i>pos)
		{
			v[i]=v[i-1];
			i--;
		}
		v[pos]=elem;
		return true;
		}

	}
}
bool Cola::Desencolar(int pos)
{int i=0;
	if(tam==0) 
			{return false;}
	else
		{cout<<"DESENCOLANDO: "<<v[pos]<<endl;
		 v[pos]=0;
				return true;
			}
}