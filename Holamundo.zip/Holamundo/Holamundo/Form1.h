#pragma once

namespace Holamundo {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btnMensaje;
	protected: 
	private: System::Windows::Forms::Label^  lblMensaje;
	private: System::Windows::Forms::TextBox^  txtMensaje;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btnMensaje = (gcnew System::Windows::Forms::Button());
			this->lblMensaje = (gcnew System::Windows::Forms::Label());
			this->txtMensaje = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// btnMensaje
			// 
			this->btnMensaje->Location = System::Drawing::Point(107, 179);
			this->btnMensaje->Name = L"btnMensaje";
			this->btnMensaje->Size = System::Drawing::Size(75, 23);
			this->btnMensaje->TabIndex = 0;
			this->btnMensaje->Text = L"Mensaje";
			this->btnMensaje->UseVisualStyleBackColor = true;
			this->btnMensaje->Click += gcnew System::EventHandler(this, &Form1::btnMensaje_Click);
			// 
			// lblMensaje
			// 
			this->lblMensaje->AutoSize = true;
			this->lblMensaje->Location = System::Drawing::Point(74, 119);
			this->lblMensaje->Name = L"lblMensaje";
			this->lblMensaje->Size = System::Drawing::Size(147, 17);
			this->lblMensaje->TabIndex = 1;
			this->lblMensaje->Text = L"Mi Primer Hola Mundo";
			// 
			// txtMensaje
			// 
			this->txtMensaje->Location = System::Drawing::Point(91, 53);
			this->txtMensaje->Name = L"txtMensaje";
			this->txtMensaje->Size = System::Drawing::Size(100, 22);
			this->txtMensaje->TabIndex = 2;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(282, 253);
			this->Controls->Add(this->txtMensaje);
			this->Controls->Add(this->lblMensaje);
			this->Controls->Add(this->btnMensaje);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnMensaje_Click(System::Object^  sender, System::EventArgs^  e) {
				 txtMensaje->Text="Hola Mundo";
			 }
	};
}

