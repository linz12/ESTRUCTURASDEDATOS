#include "StdAfx.h"
#include "Vector.h"
#include <iostream>

#define FILAS 100
#define COLUMNAS 100


using namespace std;

Vector::Vector(void)
{
	vec[FILAS][COLUMNAS]=0;
}


Vector::~Vector(void)
{
}

void Vector::cargarVector(int tamanofilas, int tamanocolumnas)
{
	for(int fila=0;fila<tamanofilas; fila++)
	{
		cout<<"rellenando la fila: ["<<fila<<"]"<<endl;
		for(int columna=0;columna<tamanocolumnas; columna++)
		{
			cout<<"rellenando la columna: ["<<columna<<"]"; 
			cin>>vec[fila][columna];
		}
	}
}

void Vector::mostrarVector(int tamanofilas, int tamanocolumnas)
{
	for(int fila=0;fila<tamanofilas; fila++)
	{
		cout<<"|";
		for(int columna=0;columna<tamanocolumnas; columna++)
		{
			cout<<" ";
			cout<<vec[fila][columna]<<" ";
			cout<<" |";
		}
		cout<<endl;
	}
}

void Vector::formula(int tamanofilas, int tamanocolumnas){
	int grande=vec[0][0];

	for(int fila=0;fila<tamanofilas; fila++)
	{	
		for(int columna=0;columna<tamanocolumnas; columna++)
		 {
		 if(grande<vec[fila][columna])
		 grande = vec[fila][columna];
		 }
	}
	cout<<"el elemento mas grande es "<<grande<<endl;
}