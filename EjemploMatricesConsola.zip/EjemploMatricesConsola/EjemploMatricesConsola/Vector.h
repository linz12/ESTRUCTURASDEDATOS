#pragma once
#define FILAS 100
#define COLUMNAS 100

class Vector
{
private:
	int vec[FILAS][COLUMNAS];
	int fila;		//fila puede ser i
	int columna;	//columna puede ser j
	int tamanofilas;
	int tamanocolumnas;

public:
	Vector(void);
	~Vector(void);

	void cargarVector(int tamanofilas, int tamanocolumnas);
	void mostrarVector(int tamanofilas, int tamanocolumnas);
	void formula(int tamanofilas, int tamanocolumnas);
};

