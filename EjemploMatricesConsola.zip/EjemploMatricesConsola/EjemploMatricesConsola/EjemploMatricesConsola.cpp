// EjemploMatricesConsola.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Vector.h"
#include "conio.h"

#define FILAS 100
#define COLUMNAS 100

using namespace std;

void main()
{
	int vec[FILAS][COLUMNAS];
	int tamanofilas;
	int tamanocolumnas;
	do{
		cout<<"ingrese el tama�o de filas del vector:";
		cin>>tamanofilas;
	}
	while((tamanofilas>FILAS) || (tamanofilas<=0));
	do{
		cout<<"ingrese el tama�o de columnas del vector:";
		cin>>tamanocolumnas;
	}
	while((tamanocolumnas>COLUMNAS) || (tamanocolumnas<=0));

	Vector vectorsito;
	vectorsito.cargarVector(tamanofilas,tamanocolumnas);
	vectorsito.mostrarVector(tamanofilas,tamanocolumnas);
	vectorsito.formula(tamanofilas,tamanocolumnas);
	getch();
}

