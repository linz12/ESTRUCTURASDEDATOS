// Cola dinamica.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Nodo.h"

using namespace std;

void Desencolar(Nodo *&inicio);

void main()
{
	Nodo *inicio=NULL;
	Nodo *fin=NULL;
	int opc=-1;
	do
	{
		cout<<"0.Salir"<<endl;
		cout<<"1.La cola esta vacia?"<<endl;
		cout<<"2.Encolar"<<endl;
		cout<<"3.Desencolar"<<endl;
		cout<<"4.Mostrar Nodos"<<endl;
		cout<<"OPCION:  "; 
		cin>>opc;
		switch (opc)
		{
		case 1:
		if(inicio==NULL)
		{
			cout<<"La cola se encuentra vacia"<<endl;
			cout<<endl;
		}
		else
		{
			cout<<"Se encuentran elemento(s) en la cola"<<endl;
		}
		break;
		case 2:
			inicio->Encolar(inicio,fin);
		break;
		case 3:
			Desencolar(inicio);
			break;
		case 4:
			if(inicio!=NULL)
			{
				inicio->Mostrar();
			}
			else
			{
				cout<<"la cola esta vacia"<<endl;
			}
		break;
		}
	}
	while(opc!=0);
}

void Desencolar(Nodo *&inicio)
{
	if(inicio!=NULL)
	{
		cout<<"Codigo: "<<inicio->datito.Codigo<<endl;
		cout<<"Nombre: "<<inicio->datito.Nombre<<endl;
		cout<<"Carrera: "<<inicio->datito.Carrera<<endl;
		inicio=inicio->siguiente;  //reemplazo el 2do nodo con el primero, y el tercero con el segundo.. etc
	}
	else
	{
		cout<<"La cola se encuentra vacia"<<endl;
	}
}