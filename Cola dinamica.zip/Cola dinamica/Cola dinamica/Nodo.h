#pragma once
#include "Dato.h"

class Nodo
{
public:
	Dato datito;
	Nodo *siguiente;

	Nodo()
	{
		siguiente= NULL;
	}
	~Nodo(void);

	void Encolar(Nodo *&inicio,Nodo *&fin);
	void Mostrar();
};

