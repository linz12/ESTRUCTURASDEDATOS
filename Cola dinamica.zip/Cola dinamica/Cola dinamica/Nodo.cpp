#include "StdAfx.h"
#include "Nodo.h"
#include <iostream>

Nodo::~Nodo(void)
{
}

void Nodo::Encolar(Nodo *&inicio,Nodo *&fin)
{
	Nodo *Elemento=new Nodo;//Creacion del nodo      nodo Elemento;
	if(inicio==NULL)
	{
		inicio=fin=Elemento;//le asigno la direccion del primer nodo
		cout<<"Codigo: ";cin>>Elemento->datito.Codigo;
		cout<<"Nombre: ";cin>>Elemento->datito.Nombre;
		cout<<"Carrera: ";cin>>Elemento->datito.Carrera;cout<<endl;
	}
	else
	{
		fin->siguiente=Elemento;//Asigno el puntero del anterior elemento al nuevo
		fin= Elemento; //Cambio l adireccion del ultimo nodo creado

		cout<<"Codigo: ";cin>>Elemento->datito.Codigo;
		cout<<"Nombre: ";cin>>Elemento->datito.Nombre;
		cout<<"Carrera: ";cin>>Elemento->datito.Carrera;cout<<endl;
	}
}

void Nodo::Mostrar()
{
	cout<<"("<<datito.Codigo<<"="<<datito.Nombre<<")";
	if(siguiente!=NULL)
	{
		cout<<" -> ";
		siguiente->Mostrar();
	}
	else
	{
		cout<<endl;
	}
}
