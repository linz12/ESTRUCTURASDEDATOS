#include "StdAfx.h"
#include "Pila.h"
#include <iostream>

#define MAX 10

using namespace std;

Pila::Pila(void)
{
	pila[MAX]=0;
	tope=-1;
}


Pila::~Pila(void)
{
}


int Pila::gettope()
{
	return tope;
}

bool Pila::Apilar(int elemento)
{
	if(pilallena()==true) //metodo pila llena
	{
		cout<<"Desbordamiento de pila"<<endl;
		return false;
	}
	else
	{
		tope=gettope()+1;   //tope++
		pila[tope]=elemento;
		return true;
	}
}

bool Pila::PilaVacia()
{
	if (gettope()==-1)   //(gettope()==-1)(tope==-1)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool Pila::pilallena()
{
	if(gettope()==(MAX-1)) //(tope==(MAX-1))
	{
		return true;
	}
	return false;
}

bool Pila::Desapilar()
{
	if(PilaVacia()==true) //
	{
		return false;
	}
	else
	{
		tope=gettope()-1; //tope--
		return true;
	}

}

void Pila::verpila()
{
	for(int i=0; i<=tope; i++)
	{
		cout<<pila[i]<<endl;
	}
}

int Pila::ValorTope()
{
	return pila[gettope()];  //pila[tope]
}

int Pila::getValor(int i)
{
	return pila[i];
}