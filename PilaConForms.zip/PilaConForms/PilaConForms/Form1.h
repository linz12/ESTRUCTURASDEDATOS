#pragma once
#include "Pila.h"
#include <iostream>

#define MAX 10


namespace PilaConForms {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	Pila pilita;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::DataGridView^  grillavalor;

	protected: 

	private: System::Windows::Forms::TextBox^  txtValor;
	private: System::Windows::Forms::Button^  btnApilar;
	private: System::Windows::Forms::Button^  btnDesapilar;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;




	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->grillavalor = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->txtValor = (gcnew System::Windows::Forms::TextBox());
			this->btnApilar = (gcnew System::Windows::Forms::Button());
			this->btnDesapilar = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillavalor))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(66, 26);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(92, 17);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Ingrese Valor";
			// 
			// grillavalor
			// 
			this->grillavalor->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grillavalor->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grillavalor->Location = System::Drawing::Point(69, 190);
			this->grillavalor->Name = L"grillavalor";
			this->grillavalor->RowTemplate->Height = 24;
			this->grillavalor->Size = System::Drawing::Size(240, 150);
			this->grillavalor->TabIndex = 1;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Valores";
			this->Column1->Name = L"Column1";
			// 
			// txtValor
			// 
			this->txtValor->Location = System::Drawing::Point(173, 23);
			this->txtValor->Name = L"txtValor";
			this->txtValor->Size = System::Drawing::Size(100, 22);
			this->txtValor->TabIndex = 2;
			// 
			// btnApilar
			// 
			this->btnApilar->Location = System::Drawing::Point(69, 105);
			this->btnApilar->Name = L"btnApilar";
			this->btnApilar->Size = System::Drawing::Size(75, 23);
			this->btnApilar->TabIndex = 3;
			this->btnApilar->Text = L"Apilar";
			this->btnApilar->UseVisualStyleBackColor = true;
			this->btnApilar->Click += gcnew System::EventHandler(this, &Form1::btnApilar_Click);
			// 
			// btnDesapilar
			// 
			this->btnDesapilar->Location = System::Drawing::Point(270, 105);
			this->btnDesapilar->Name = L"btnDesapilar";
			this->btnDesapilar->Size = System::Drawing::Size(75, 23);
			this->btnDesapilar->TabIndex = 4;
			this->btnDesapilar->Text = L"Desapilar";
			this->btnDesapilar->UseVisualStyleBackColor = true;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(411, 382);
			this->Controls->Add(this->btnDesapilar);
			this->Controls->Add(this->btnApilar);
			this->Controls->Add(this->txtValor);
			this->Controls->Add(this->grillavalor);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillavalor))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnApilar_Click(System::Object^  sender, System::EventArgs^  e) {
				 int aux, dato;
				 aux=System::Convert::ToInt32(txtValor->Text);
				 if(pilita.Apilar(aux))
				 {
					 grillavalor->ColumnCount=1;
					 grillavalor->RowCount=pilita.gettope()+1;
					 for(int i=0; i<pilita.gettope()+1; i++)
					 {
						 dato=pilita.getValor(i);
						 grillavalor->Rows[i]->Cells[0]->Value=System::Convert::ToInt32(dato);
					 }
				 }
			 }
};
}

